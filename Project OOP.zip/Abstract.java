public abstract class Abstract {
    
    public abstract boolean search(String a, String b);
    public abstract void delete(String a, String b);
    public abstract void print();
    
    
}