public interface methods {
    
    public void update();
    public void read();
    
}

